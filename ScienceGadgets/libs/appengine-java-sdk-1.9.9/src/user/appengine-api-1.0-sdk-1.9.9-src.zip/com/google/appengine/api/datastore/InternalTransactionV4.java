package com.google.appengine.api.datastore;
import com.google.appengine.api.utils.FutureWrapper;
import com.google.apphosting.api.ApiProxy.ApiConfig;
import com.google.apphosting.datastore.DatastoreV4;
import com.google.apphosting.datastore.DatastoreV4.BeginTransactionResponse;
import com.google.apphosting.datastore.DatastoreV4.CommitRequest;
import com.google.apphosting.datastore.DatastoreV4.CommitResponse;
import com.google.apphosting.datastore.DatastoreV4.DatastoreV4Service;
import com.google.apphosting.datastore.DatastoreV4.DatastoreV4Service.Method;
import com.google.apphosting.datastore.DatastoreV4.RollbackRequest;
import com.google.apphosting.datastore.DatastoreV4.RollbackResponse;
import com.google.apphosting.datastore.EntityV4;
import com.google.common.collect.MapMaker;
import com.google.common.collect.Maps;
import com.google.common.primitives.Bytes;
import com.google.protobuf.ByteString;
import com.google.protobuf.MessageLite;

import java.util.Map;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Implementation of the V4-specific logic to handle a {@link Transaction}.
 *
 * In V4, puts and gets are stored on the client until commit. This class serializes
 * mutations as they are received to avoid memory penalties associated with the full
 * proto objects.
 */
class InternalTransactionV4 implements TransactionImpl.InternalTransaction {

  /**
   * Generates a unique identifier (for a given runtime) which can be used for later
   * lookup of the instance.
   */
  private static final AtomicLong clientIdGenerator = new AtomicLong();

  /**
   * Used to store {@link InternalTransactionV4} objects for reidentification when a
   * potentially wrapped Transaction object is passed back to the SDK in a future call.
   * Each {@link InternalTransactionV4} instance is wrapped in a {@link TransactionImpl}.
   * We use weak references in this static map because this object's purpose is tied to
   * the lifetime of the wrapper.
   */
  private static final Map<String, InternalTransactionV4> internalTransactionRegister =
      new MapMaker().weakValues().makeMap();

  /**
   * The ID reported through {@link #getId()}. This ID is also used for instance lookup, see
   * {@link #getById(String)}.
   */
  private final String clientId = Long.toString(clientIdGenerator.getAndIncrement());

  /**
   * The {@link Future} associated with the BeginTransaction RPC we sent to the
   * datastore server.
   */
  private final Future<BeginTransactionResponse> beginTxnFuture;

  /**
   * The list of mutations (deferred Put/Delete operations) that will be sent to the server as part
   * of the Commit RPC.  A linked map is used to generate consistent results for unit tests;
   * however iteration order shouldn't affect correctness.
   */
  private final Map<EntityV4.Key, byte[]> mutationMap = Maps.newLinkedHashMap();

  private final CommitRequest.Builder commitReqBuilder = CommitRequest.newBuilder();

  private final ApiConfig apiConfig;

  private boolean isWritable = true;

  /**
   * Production code should use {@link #create(ApiConfig, Future)}.
   * This constructor is visible because unit tests override the makeAsync function below.
   */
  InternalTransactionV4(ApiConfig apiConfig, Future<BeginTransactionResponse> beginTxnFuture) {
    this.apiConfig = apiConfig;
    this.beginTxnFuture = beginTxnFuture;
  }

  static InternalTransactionV4 create(ApiConfig apiConfig,
      Future<BeginTransactionResponse> future) {
    InternalTransactionV4 txn = new InternalTransactionV4(apiConfig, future);
    internalTransactionRegister.put(txn.clientId, txn);
    return txn;
  }

  /**
   * Provides the unique identifier for the txn.
   * Blocks on the future since the handle comes back from the datastore
   * server.
   */
  ByteString getHandle() {
    return FutureHelper.quietGet(beginTxnFuture).getTransaction();
  }

  /**
   * Schedules a put operation for when this transaction is committed.
   */
  void deferPut(Entity entity) {
    deferPut(DataTypeTranslator.toV4Entity(entity).build());
  }

  /**
   * Adds a serialized copy of a mutation to the map.
   */
  private void setMutation(EntityV4.Key key, DatastoreV4.Mutation.Builder mutationBuilder) {
    if (!isWritable) {
      throw new IllegalStateException("Transaction is not writable.");
    }
    commitReqBuilder.addMutation(mutationBuilder.build());
    mutationMap.put(key, commitReqBuilder.buildPartial().toByteArray());
    commitReqBuilder.clearMutation();
  }

  void deferPut(EntityV4.Entity entityProto) {
    setMutation(entityProto.getKey(), DatastoreV4.Mutation.newBuilder()
        .setOp(DatastoreV4.Mutation.Operation.UPSERT)
        .setEntity(entityProto));
  }

  void deferDelete(Key key) {
    setMutation(DataTypeTranslator.toV4Key(key).build(), DatastoreV4.Mutation.newBuilder()
        .setOp(DatastoreV4.Mutation.Operation.DELETE)
        .setKey(DataTypeTranslator.toV4Key(key).build()));
  }

  <T extends MessageLite> Future<Void> makeAsyncCall(DatastoreV4Service.Method method,
      byte[] request, T defaultResponseProto) {
    return new FutureWrapper<T, Void>(
        DatastoreApiHelper.makeAsyncCall(apiConfig, method, request, defaultResponseProto)) {
      @Override
      protected Void wrap(T ignore) throws Exception {
        return null;
      }

      @Override
      protected Throwable convertException(Throwable cause) {
        return cause;
      }
    };
  }

  @Override
  public Future<Void> doCommitAsync() {
    isWritable = false;
    byte[][] protoSegmentsArray = new byte[mutationMap.size() + 1][];
    protoSegmentsArray[0] = CommitRequest.newBuilder()
        .setTransaction(getHandle())
        .build().toByteArray();
    int arrayIndex = 1;
    for (byte[] mutData : mutationMap.values()) {
      protoSegmentsArray[arrayIndex++] = mutData;
    }
    byte[] encodedRequest = Bytes.concat(protoSegmentsArray);
    mutationMap.clear();
    return makeAsyncCall(Method.Commit, encodedRequest, CommitResponse.getDefaultInstance());
  }

  @Override
  public Future<Void> doRollbackAsync() {
    isWritable = false;
    byte[] requestBytes = RollbackRequest.newBuilder()
        .setTransaction(getHandle())
        .build().toByteArray();
    mutationMap.clear();
    return makeAsyncCall(Method.Rollback, requestBytes, RollbackResponse.getDefaultInstance());
  }

  @Override
  public String getId() {
    return clientId;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }

    InternalTransactionV4 that = (InternalTransactionV4) o;

    return getHandle() == that.getHandle();
  }

  @Override
  public int hashCode() {
    return getHandle().hashCode();
  }

  /**
   * Locates the {@link InternalTransactionV4} object associated with a
   * {@link Transaction} by looking up the ID in an static, threadsafe map.
   * @throws IllegalArgumentException If a txn object is not found.
   * @return Internal transaction object associated with the given ID.
   */
  static InternalTransactionV4 getById(String txnClientId) {
    InternalTransactionV4 txnImpl = internalTransactionRegister.get(txnClientId);
    if (txnImpl == null) {
      throw new IllegalArgumentException("Transaction not found with ID: " + txnClientId);
    }
    return txnImpl;
  }
}
