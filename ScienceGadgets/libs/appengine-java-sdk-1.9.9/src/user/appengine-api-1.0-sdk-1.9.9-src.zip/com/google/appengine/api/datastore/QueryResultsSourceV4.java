package com.google.appengine.api.datastore;

import com.google.apphosting.api.ApiProxy.ApiConfig;
import com.google.apphosting.datastore.DatastoreV3Pb.CompiledCursor;
import com.google.apphosting.datastore.DatastoreV4;
import com.google.apphosting.datastore.DatastoreV4.ContinueQueryRequest;
import com.google.apphosting.datastore.DatastoreV4.ContinueQueryResponse;
import com.google.apphosting.datastore.DatastoreV4.DatastoreV4Service.Method;
import com.google.apphosting.datastore.DatastoreV4.QueryResultBatch;
import com.google.apphosting.datastore.DatastoreV4.QueryResultBatch.MoreResultsType;
import com.google.apphosting.datastore.DatastoreV4.RunQueryResponse;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.google.protobuf.InvalidProtocolBufferException;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Future;

/**
 * V4 service specific code for iterating query results and requesting more results.
 * Instances can be shared between queries using the same ApiConfig.
 */
class QueryResultsSourceV4 extends
    BaseQueryResultsSource<RunQueryResponse, ContinueQueryRequest, ContinueQueryResponse> {

  private final ApiConfig apiConfig;

  QueryResultsSourceV4(DatastoreCallbacks callbacks, FetchOptions fetchOptions, Transaction txn,
      Query query, Future<RunQueryResponse> runQueryResponse, ApiConfig apiConfig) {
    super(callbacks, fetchOptions, txn, query, runQueryResponse);
    this.apiConfig = apiConfig;
  }

  @Override
  ContinueQueryRequest buildNextCallPrototype(RunQueryResponse initialResponse) {
    return ContinueQueryRequest.newBuilder()
        .setQueryHandle(initialResponse.getQueryHandle())
        .build();
  }

  @Override
  Future<ContinueQueryResponse> makeNextCall(ContinueQueryRequest prototype,
      Integer fetchCountOrNull, Integer offsetOrNull) {
    return DatastoreApiHelper.makeAsyncCall(apiConfig, Method.ContinueQuery, prototype,
        ContinueQueryResponse.getDefaultInstance());
  }

  @Override
  WrappedQueryResult wrapInitialResult(RunQueryResponse initialResponse) {
    return new WrappedQueryResultV4(initialResponse.getBatch());
  }

  @Override
  WrappedQueryResult wrapResult(ContinueQueryResponse res) {
    return new WrappedQueryResultV4(res.getBatch());
  }

  private static class WrappedQueryResultV4 implements WrappedQueryResult {
    private final QueryResultBatch batch;

    WrappedQueryResultV4(QueryResultBatch batch) {
      this.batch = batch;
    }

    @Override
    public Cursor getEndCursor() {
      if (batch.hasEndCursor()) {
        try {
          return new Cursor(CompiledCursor.PARSER.parseFrom(batch.getEndCursor()));
        } catch (InvalidProtocolBufferException e) {
          throw new RuntimeException("Can't parse cursor", e);
        }
      }
      return null;
    }

    @Override
    public List<Entity> getEntities(Collection<Projection> projections) {
      List<Entity> entityList = Lists.newArrayListWithCapacity(batch.getEntityResultCount());
      if (projections.isEmpty()) {
        for (DatastoreV4.EntityResult entityResult : batch.getEntityResultList()) {
          entityList.add(DataTypeTranslator.toEntity(entityResult.getEntity()));
        }
      } else {
        for (DatastoreV4.EntityResult entityResult : batch.getEntityResultList()) {
          entityList.add(DataTypeTranslator.toEntity(entityResult.getEntity(), projections));
        }
      }
      return entityList;
    }

    @Override
    public List<Cursor> getResultCursors() {
      return Collections.<Cursor>nCopies(batch.getEntityResultCount(), null);
    }

    @Override
    public Cursor getSkippedResultsCursor() {
      return null;
    }

    @Override
    public boolean hasMoreResults() {
      return batch.getMoreResults() == MoreResultsType.NOT_FINISHED;
    }

    @Override
    public int numSkippedResults() {
      return batch.getSkippedResults();
    }

    @Override
    public List<Index> getIndexInfo(Collection<Index> monitoredIndexBuffer) {
      return ImmutableList.of();
    }
  }
}
