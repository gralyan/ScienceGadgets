// Copyright 2012 Google Inc. All rights reserved.

package com.google.appengine.api.datastore;

import com.google.appengine.api.datastore.DatastoreServiceConfig.ApiVersion;

/**
 * Creates DatastoreService instances.
 *
 */
final class DatastoreServiceFactoryImpl implements IDatastoreServiceFactory {

  @Override
  public DatastoreService getDatastoreService(DatastoreServiceConfig config) {
    return new DatastoreServiceImpl(getAsyncDatastoreService(config));
  }

  @Override
  public AsyncDatastoreServiceInternal getAsyncDatastoreService(DatastoreServiceConfig config) {
    TransactionStack txnStack = new TransactionStackImpl();
    if (config.getApiVersion() == ApiVersion.V4) {
      return new AsyncDatastoreV4ServiceImpl(config, txnStack);
    } else {
      return new AsyncDatastoreServiceImpl(config, txnStack);
    }
  }
}
